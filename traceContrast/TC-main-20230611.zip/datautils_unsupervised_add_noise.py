from cProfile import label
import os
import numpy as np
import pandas as pd
import math
import random
from datetime import datetime
import pickle
from utils import pkl_load, pad_nan_to_target
from scipy.io.arff import loadarff
from sklearn.preprocessing import StandardScaler, MinMaxScaler

import scipy.io as scio
import torch
import torch.nn.functional as F
import torch_cluster
import torch_geometric.nn as pyg_nn

date_name = '0916'

#### load data
def load_SCN():
    # scn_data_path = f'D:/lab/scn/3d/20220516/20210918/INTERP/0918_6-29.mat'
    # scn_data_path = f'D:/lab/scn/Data_0712/20210602_CT02-11/20210602_data.mat'
    scn_data_path = f'D:/lab/scn/3d/20220516/20210916/INTERP/0916_int_7-30.mat' # 0916_int_7-30
    # scn_data_path = f'D:/lab/scn/3d/spike_int.mat' # 0916
    # scn_data_path = f'D:/lab/scn/3d/20221010/spike_int.mat'
    # scn_data_path = f'D:/lab/scn/3d/2022{date_name}/2022{date_name}_data.mat'
    # scn_data_path = f'D:/lab/scn/3d/0916_interval.mat'
    scn_data = scio.loadmat(scn_data_path)

    trace = scn_data['trace'].T # trace

    trace = trace[:,0:4800] # 4800 sample 2400
    train = np.reshape(trace, (trace.shape[0], 24, 200)) # 24 200 sample 100

    # ## TODO shuffle periods
    # for i in range(trace.shape[0]):
    #     t_ind = np.random.permutation(24)
    #     train[i] = train[i, t_ind,:]
    # scio.savemat(f'./TC-results/exp-0610/shuffle_periods.mat', {'dff':train})
    # ##

    ## TODO shuffle time points
    # for i in range(trace.shape[0]):
    #     for t in range(24):
    #         s_ind = np.random.permutation(200)
    #         train[i,t,:] = train[i, t, s_ind]
    # scio.savemat(f'./TC-results/exp-0610/shuffle_time.mat', {'dff':train})
    ##

    ## TODO: change to gaussian noise
    # for i in range(train.shape[0]):
    #     for t in range(24):
    #         sample = train[i,t,:]
    #         miu = np.mean(sample)
    #         sigma = np.std(sample)
    #         random_noise = np.random.normal(miu,sigma,sample.shape)
    #         train[i,t,:] = random_noise
    # scio.savemat(f'./TC-results/exp-0610/gaussian_time.mat', {'dff':train})
    ##

    ## TODO: change 24h to gaussian noise
    # for i in range(trace.shape[0]):
    #     sample = trace[i,:]
    #     miu = np.mean(sample)
    #     sigma = np.std(sample)
    #     random_noise = np.random.normal(miu,sigma,sample.shape)
    #     trace[i,:] = random_noise
    # train = np.reshape(trace, (trace.shape[0], 24, 200))
    # scio.savemat(f'./TC-results/exp-0610/gaussian_period.mat', {'dff':train})
    ##

    ## TODO: all to noise
    miu = np.mean(train)
    sigma = np.std(train)
    random_noise = np.random.normal(miu,sigma,train.shape)
    train = random_noise
    scio.savemat(f'./TC-results/exp-0610/gaussian_all.mat', {'dff':train})
    ##

    # train = scn_data['s_i'] # trace, s_o

    return train

    ### 以下作废
    # train = trace[:,:,np.newaxis]

    # data_file1 = 'D:/lab/scn/3d/相空间分类/trainingSet/20210511_CT02-11_train.mat'
    # data_file2 = 'D:/lab/scn/3d/相空间分类/trainingSet/20210517_CT10-19_train.mat'
    # data_file3 = 'D:/lab/scn/3d/相空间分类/trainingSet/20210527_CT18-03_train.mat'
    # data_file4 = 'D:/lab/scn/3d/相空间分类/trainingSet/20210602_CT02-11_train.mat'

    # data1 = scio.loadmat(data_file1)
    # data2 = scio.loadmat(data_file2)
    # data3 = scio.loadmat(data_file3)
    # data4 = scio.loadmat(data_file4)

    # signal = np.concatenate((data1['phase'],data2['phase'],data3['phase'],data4['phase']))
    # y = np.concatenate((data1['label'],data2['label'],data3['label'],data4['label']))

    # test_file = 'D:/lab/scn/3d/相空间分类/trainingSet/'
    # train_df = pd.read_csv(train_file, sep='\t', header=None)
    # test_df = pd.read_csv(test_file, sep='\t', header=None)
    # train_array = np.array(train_df)
    # test_array = np.array(test_df)

    # # Move the labels to {0, ..., L-1}
    # labels = np.unique(y)
    # transform = {}
    # for i, l in enumerate(labels):
    #     transform[l] = i
 
    # # random permute
    # neuron_num = signal.shape[0]
    # new_order = np.random.permutation(neuron_num)
    # new_signal = signal[new_order,:,:]
    # new_y = y[new_order,:]
    # new_label = np.vectorize(transform.get)(new_y) # 注意：label变为0-5

    # divide train and test dataset
    # divide = np.int(np.floor(0.7*neuron_num))
    # train = new_signal[0:divide,:,:]
    # test = new_signal[divide:,:,:]
    # train_labels = new_label[0:divide,:]
    # test_labels = new_label[divide:,:]

    # train = train_array[:, 1:].astype(np.float64)
    # train_labels = np.vectorize(transform.get)(train_array[:, 0])
    # test = test_array[:, 1:].astype(np.float64)
    # test_labels = np.vectorize(transform.get)(test_array[:, 0])

    # Normalization for non-normalized datasets
    # To keep the amplitude information, we do not normalize values over
    # individual time series, but on the whole dataset
    # if dataset not in [
    #     'AllGestureWiimoteX',
    #     'AllGestureWiimoteY',
    #     'AllGestureWiimoteZ',
    #     'BME',
    #     'Chinatown',
    #     'Crop',
    #     'EOGHorizontalSignal',
    #     'EOGVerticalSignal',
    #     'Fungi',
    #     'GestureMidAirD1',
    #     'GestureMidAirD2',
    #     'GestureMidAirD3',
    #     'GesturePebbleZ1',
    #     'GesturePebbleZ2',
    #     'GunPointAgeSpan',
    #     'GunPointMaleVersusFemale',
    #     'GunPointOldVersusYoung',
    #     'HouseTwenty',
    #     'InsectEPGRegularTrain',
    #     'InsectEPGSmallTrain',
    #     'MelbournePedestrian',
    #     'PickupGestureWiimoteZ',
    #     'PigAirwayPressure',
    #     'PigArtPressure',
    #     'PigCVP',
    #     'PLAID',
    #     'PowerCons',
    #     'Rock',
    #     'SemgHandGenderCh2',
    #     'SemgHandMovementCh2',
    #     'SemgHandSubjectCh2',
    #     'ShakeGestureWiimoteZ',
    #     'SmoothSubspace',
    #     'UMD'
    # ]:
    #     return train[..., np.newaxis], train_labels, test[..., np.newaxis], test_labels
    
    # mean = np.nanmean(train)
    # std = np.nanstd(train)
    # train = (train - mean) / std
    # test = (test - mean) / std
    # return train[..., np.newaxis], train_labels, test[..., np.newaxis], test_labels
    


def load_UCR(dataset):
    train_file = os.path.join('datasets/UCR', dataset, dataset + "_TRAIN.tsv")
    test_file = os.path.join('datasets/UCR', dataset, dataset + "_TEST.tsv")
    train_df = pd.read_csv(train_file, sep='\t', header=None)
    test_df = pd.read_csv(test_file, sep='\t', header=None)
    train_array = np.array(train_df)
    test_array = np.array(test_df)

    # Move the labels to {0, ..., L-1}
    labels = np.unique(train_array[:, 0])
    transform = {}
    for i, l in enumerate(labels):
        transform[l] = i

    train = train_array[:, 1:].astype(np.float64)
    train_labels = np.vectorize(transform.get)(train_array[:, 0])
    test = test_array[:, 1:].astype(np.float64)
    test_labels = np.vectorize(transform.get)(test_array[:, 0])

    # Normalization for non-normalized datasets
    # To keep the amplitude information, we do not normalize values over
    # individual time series, but on the whole dataset
    if dataset not in [
        'AllGestureWiimoteX',
        'AllGestureWiimoteY',
        'AllGestureWiimoteZ',
        'BME',
        'Chinatown',
        'Crop',
        'EOGHorizontalSignal',
        'EOGVerticalSignal',
        'Fungi',
        'GestureMidAirD1',
        'GestureMidAirD2',
        'GestureMidAirD3',
        'GesturePebbleZ1',
        'GesturePebbleZ2',
        'GunPointAgeSpan',
        'GunPointMaleVersusFemale',
        'GunPointOldVersusYoung',
        'HouseTwenty',
        'InsectEPGRegularTrain',
        'InsectEPGSmallTrain',
        'MelbournePedestrian',
        'PickupGestureWiimoteZ',
        'PigAirwayPressure',
        'PigArtPressure',
        'PigCVP',
        'PLAID',
        'PowerCons',
        'Rock',
        'SemgHandGenderCh2',
        'SemgHandMovementCh2',
        'SemgHandSubjectCh2',
        'ShakeGestureWiimoteZ',
        'SmoothSubspace',
        'UMD'
    ]:
        return train[..., np.newaxis], train_labels, test[..., np.newaxis], test_labels
    
    mean = np.nanmean(train)
    std = np.nanstd(train)
    train = (train - mean) / std
    test = (test - mean) / std
    return train[..., np.newaxis], train_labels, test[..., np.newaxis], test_labels


def load_UEA(dataset):
    train_data = loadarff(f'datasets/UEA/{dataset}/{dataset}_TRAIN.arff')[0]
    test_data = loadarff(f'datasets/UEA/{dataset}/{dataset}_TEST.arff')[0]
    
    def extract_data(data):
        res_data = []
        res_labels = []
        for t_data, t_label in data:
            t_data = np.array([ d.tolist() for d in t_data ])
            t_label = t_label.decode("utf-8")
            res_data.append(t_data)
            res_labels.append(t_label)
        return np.array(res_data).swapaxes(1, 2), np.array(res_labels)
    
    train_X, train_y = extract_data(train_data)
    test_X, test_y = extract_data(test_data)
    
    scaler = StandardScaler()
    scaler.fit(train_X.reshape(-1, train_X.shape[-1]))
    train_X = scaler.transform(train_X.reshape(-1, train_X.shape[-1])).reshape(train_X.shape)
    test_X = scaler.transform(test_X.reshape(-1, test_X.shape[-1])).reshape(test_X.shape)
    
    labels = np.unique(train_y)
    transform = { k : i for i, k in enumerate(labels)}
    train_y = np.vectorize(transform.get)(train_y)
    test_y = np.vectorize(transform.get)(test_y)
    return train_X, train_y, test_X, test_y
    
    
def load_forecast_npy(name, univar=False):
    data = np.load(f'datasets/{name}.npy')    
    if univar:
        data = data[: -1:]
        
    train_slice = slice(None, int(0.6 * len(data)))
    valid_slice = slice(int(0.6 * len(data)), int(0.8 * len(data)))
    test_slice = slice(int(0.8 * len(data)), None)
    
    scaler = StandardScaler().fit(data[train_slice])
    data = scaler.transform(data)
    data = np.expand_dims(data, 0)

    pred_lens = [24, 48, 96, 288, 672]
    return data, train_slice, valid_slice, test_slice, scaler, pred_lens, 0


def _get_time_features(dt):
    return np.stack([
        dt.minute.to_numpy(),
        dt.hour.to_numpy(),
        dt.dayofweek.to_numpy(),
        dt.day.to_numpy(),
        dt.dayofyear.to_numpy(),
        dt.month.to_numpy(),
        dt.weekofyear.to_numpy(),
    ], axis=1).astype(np.float)


def load_forecast_csv(name, univar=False):
    data = pd.read_csv(f'datasets/{name}.csv', index_col='date', parse_dates=True)
    dt_embed = _get_time_features(data.index)
    n_covariate_cols = dt_embed.shape[-1]
    
    if univar:
        if name in ('ETTh1', 'ETTh2', 'ETTm1', 'ETTm2'):
            data = data[['OT']]
        elif name == 'electricity':
            data = data[['MT_001']]
        else:
            data = data.iloc[:, -1:]
        
    data = data.to_numpy()
    if name == 'ETTh1' or name == 'ETTh2':
        train_slice = slice(None, 12*30*24)
        valid_slice = slice(12*30*24, 16*30*24)
        test_slice = slice(16*30*24, 20*30*24)
    elif name == 'ETTm1' or name == 'ETTm2':
        train_slice = slice(None, 12*30*24*4)
        valid_slice = slice(12*30*24*4, 16*30*24*4)
        test_slice = slice(16*30*24*4, 20*30*24*4)
    else:
        train_slice = slice(None, int(0.6 * len(data)))
        valid_slice = slice(int(0.6 * len(data)), int(0.8 * len(data)))
        test_slice = slice(int(0.8 * len(data)), None)
    
    scaler = StandardScaler().fit(data[train_slice])
    data = scaler.transform(data)
    if name in ('electricity'):
        data = np.expand_dims(data.T, -1)  # Each variable is an instance rather than a feature
    else:
        data = np.expand_dims(data, 0)
    
    if n_covariate_cols > 0:
        dt_scaler = StandardScaler().fit(dt_embed[train_slice])
        dt_embed = np.expand_dims(dt_scaler.transform(dt_embed), 0)
        data = np.concatenate([np.repeat(dt_embed, data.shape[0], axis=0), data], axis=-1)
    
    if name in ('ETTh1', 'ETTh2', 'electricity'):
        pred_lens = [24, 48, 168, 336, 720]
    else:
        pred_lens = [24, 48, 96, 288, 672]
        
    return data, train_slice, valid_slice, test_slice, scaler, pred_lens, n_covariate_cols


def load_anomaly(name):
    res = pkl_load(f'datasets/{name}.pkl')
    return res['all_train_data'], res['all_train_labels'], res['all_train_timestamps'], \
           res['all_test_data'],  res['all_test_labels'],  res['all_test_timestamps'], \
           res['delay']


def gen_ano_train_data(all_train_data):
    maxl = np.max([ len(all_train_data[k]) for k in all_train_data ])
    pretrain_data = []
    for k in all_train_data:
        train_data = pad_nan_to_target(all_train_data[k], maxl, axis=0)
        pretrain_data.append(train_data)
    pretrain_data = np.expand_dims(np.stack(pretrain_data), 2)
    return pretrain_data
